## ShareYourSearch Application(UpgradedSleepingInTheLibrary)

ShareYourSearch is an app that supports search photos, check large image, share photos, and reorder cells features and save your recent searches.

## Implementation

View controller has most use of UICollectionViewDataSource, UICollectionViewDelegate,  UICollectionViewDelegateFlowLayout, and  UICollectionViewCell. Also, this app implements search and share function by using Flickr Restful API, UITextDelegate and UIActivityViewController. 

## How to build

 1.Type your text you want to search in the search input box.
 2.Select multiple images out from the collection view.
 3.You can share selected images with your friends & family.

## Requirements

 - Xcode 10
 - Swift 4
 - iOS 11


